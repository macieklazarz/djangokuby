from django.contrib import admin
from .models import Tuz

# Register your models here.
admin.site.register(Tuz)
